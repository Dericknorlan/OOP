public abstract class Persons extends Group3 {

}
