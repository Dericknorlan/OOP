public class Main {
        public static void main(String[] args) {
                Group3 Kelompok = new Group3("Alicia Juanita Lisal", 5, "NPLC App", "Penghuni Lantai 5");
                PersonalDetails GilbertPD = new PersonalDetails(
                                "0806022310001",
                                "Gilbert De Foucauld Winardy",
                                "www.gilbertwinardy@gmail.com",
                                "Catholic",
                                "02-12-2004",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "Makassar",
                                'M',
                                "Jl. Baji Minasa 2 No. 8 RT.003 RW.003",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "Prop. Sulawesi Selatan, Makassar, Kec. Mariso",
                                "Makassar, Kec. Mariso, Mariso",
                                90126,
                                "-",
                                "-",
                                "-",
                                "-",
                                0,
                                "081356772225",
                                "-",
                                "081356772225",
                                "-");
                Jobdesc GilbertJD = new Jobdesc(
                                "Frontend",
                                "Pending",
                                "Member",
                                "Kapan Kapan",
                                "Coba dulu yang penting jadi");
                SocialMedia GilbertSM = new SocialMedia(
                                "gibe6183",
                                "081356772225",
                                "Gilbert",
                                "@gilbertwinardy",
                                "-",
                                "-",
                                "-",
                                "-",
                                "-");

                System.out.println("========================================\nGilbert's Personal Details : \n");
                GilbertPD.displayDetails();

                System.out.println("\n\nGilbert's Job Description : \n");
                GilbertJD.displayDetails();

                System.out.println("\n\nGilbert's Social Media Details : \n");
                GilbertSM.displayDetails();
                System.out.println("========================================");

                PersonalDetails AliciaPD = new PersonalDetails(
                                "0806022310002",
                                "Alicia Juanita Lisal",
                                "alicia.lisal94@gmail.com",
                                "Christian",
                                "19-12-2005",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "Makassar",
                                'F',
                                "Komp. Espana",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "-",
                                "-",
                                90225,
                                "-",
                                "-",
                                "-",
                                "-",
                                0,
                                "-",
                                "-",
                                "08990080560",
                                "-");
                Jobdesc AliciaJD = new Jobdesc(
                                "Backend",
                                "Pending",
                                "Leader",
                                "semester 2 slesai amin",
                                "apa");
                SocialMedia AliciaSM = new SocialMedia(
                                "alicia_lisal",
                                "08990080560",
                                "", "@alicia_lisal",
                                "-",
                                "-",
                                "-",
                                "-",
                                "-");

                System.out.println("\n\n========================================\nAlicia's Personal Details : \n");
                AliciaPD.displayDetails();

                System.out.println("\n\nAlicia's Job Description : \n");
                AliciaJD.displayDetails();

                System.out.println("\n\nAlicia's Social Media Details : \n");
                AliciaSM.displayDetails();
                System.out.println("========================================");

                PersonalDetails ChaidenPD = new PersonalDetails(
                                "0806022310023",
                                "Chaiden Richardo Foanto",
                                "chaiden.foanto@gmail.com",
                                "Buddhist",
                                "26-04-2005",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "Makassar",
                                'M',
                                "Jl. Sungai Tallo No. 11 RT.02 RW.02",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "-",
                                "-",
                                90115,
                                "-",
                                "-",
                                "-",
                                "-",
                                0,
                                "3625946",
                                "-",
                                "08510806113",
                                "-");
                Jobdesc ChaidenJD = new Jobdesc(
                                "Backend",
                                "Pending",
                                "Member",
                                "Week 14 Semester 2 SELESAII AMIN",
                                "Bikin fitur, hosting, dll");
                SocialMedia ChaidenSM = new SocialMedia(
                                "Chaiden103",
                                "085108086113",
                                "Chaiden R Foanto",
                                "chaidenfoanto",
                                "chaidenfoanto",
                                "-",
                                "-",
                                "-",
                                "-");

                System.out.println("\n\n========================================\nChaiden's Personal Details : \n");
                ChaidenPD.displayDetails();

                System.out.println("\n\nChaiden's Job Description : \n");
                ChaidenJD.displayDetails();

                System.out.println("\n\nChaiden's Social Media Details : \n");
                ChaidenSM.displayDetails();
                System.out.println("========================================");

                PersonalDetails AurelPD = new PersonalDetails(
                                "0806022310024",
                                "Aurelia Davine Putri Nata",
                                "nataaureliadavineputri@gmail.com",
                                "Kristen Protestan",
                                "03-06-2005",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "Makassar",
                                'F',
                                "Jl. Citra Sudiang Indah Y9 no 9",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "-",
                                "-",
                                90242,
                                "-",
                                "-",
                                "-",
                                "-",
                                0,
                                "-",
                                "-",
                                "081342496226",
                                "-");
                Jobdesc AurelJD = new Jobdesc(
                                "ui/ux",
                                "pending",
                                "member",
                                "semester dua selesai amins",
                                "gek");
                SocialMedia AurelSM = new SocialMedia(
                                "aurlrel",
                                "081342496226",
                                "",
                                "@aurlrel",
                                "-",
                                "-",
                                "-",
                                "-",
                                "-");

                System.out.println("\n\n========================================\nAurel's Personal Details : \n");
                AurelPD.displayDetails();

                System.out.println("\n\nAurel's Job Description : \n");
                AurelJD.displayDetails();

                System.out.println("\n\nAurel's Social Media Details : \n");
                AurelSM.displayDetails();
                System.out.println("========================================");

                PersonalDetails DerickPD = new PersonalDetails(
                                "0806022310005",
                                "Derick Norlan",
                                "dericknorlan@gmail.com",
                                "Buddhist",
                                "16-10-05",
                                "Indonesia, Prop. Sumatera Utara, Medan",
                                "Medan",
                                'M',
                                "Komp. Rosewood",
                                "Indonesia, Prop. Sulawesi Selatan, Makassar",
                                "-",
                                "-",
                                90225,
                                "-",
                                "-",
                                "-",
                                "-",
                                0,
                                "-",
                                "-",
                                "081356558061",
                                "-");
                Jobdesc DerickJD = new Jobdesc(
                                "Nganggur",
                                "Pending",
                                "Member",
                                "insyallah semester 2 slesai",
                                "Stres");
                SocialMedia DerickSM = new SocialMedia(
                                "derick1610",
                                "081356558061",
                                "-",
                                "drck_n",
                                "-",
                                "-",
                                "-",
                                "-",
                                "-");

                System.out.println("\n\n========================================\nDerick's Personal Details : \n");
                DerickPD.displayDetails();

                System.out.println("\n\nDerick's Job Description : \n");
                DerickJD.displayDetails();

                System.out.println("\n\nDerick's Social Media Media : \n");
                DerickSM.displayDetails();
                System.out.println("========================================");
                System.out.println("\nGroup's Data\n");

                Kelompok.displayDetails();
        }
}
